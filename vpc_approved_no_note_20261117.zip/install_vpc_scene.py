#!/usr/bin/env python3
"""Install approved no-note VPC desktop/mobile backgrounds without floating overlays.
Safe idempotent patch: updates two image URLs in the exact approved scene style,
removes the one obsolete note DOM block, and aligns existing invisible book buttons.
All existing book reader scripts, social tags, shopping links and published text remain.
"""
from pathlib import Path
import re
import hashlib
import shutil
import sys

ROOT = Path.cwd()
INDEX = ROOT / 'index.html'
ASSETS = ROOT / 'assets' / 'vpc-scene'
SRC = Path(__file__).resolve().parent
MARKER = 'vpc-approved-no-note-scene-20261117'
ASSET_FILES = (
    'vpc-scene-desktop-20261117.jpg',
    'vpc-scene-mobile-20261117.jpg',
)

def main():
    if not INDEX.exists():
        raise SystemExit('ABORT: index.html missing; no modifications')
    for f in ASSET_FILES:
        src = SRC / f
        if not src.exists() or src.stat().st_size < 100000:
            raise SystemExit('ABORT: missing/undersized approved scene asset: ' + f)
    s = INDEX.read_text(encoding='utf-8')
    if MARKER in s:
        print('Already installed; no changes needed')
        return

    if len(s) < 7_000_000:
        raise SystemExit('ABORT: unexpected homepage size. Review source before proceeding.')
    if s.count('<div class="office-frame approved-scene">') != 1:
        raise SystemExit('ABORT: expected one approved office scene')
    for i in range(4):
        pat = f'data-book="{i}" onclick="openReader({i})"'
        if s.count(pat) != 1:
            raise SystemExit('ABORT: missing or duplicated original book-click handler '+pat)
    if 'vpc-authentic-cover' in s:
        raise SystemExit('ABORT: unexpected floating cover HTML remains; no changes')

    # The original scene was embedded directly as huge base64 PNGs in v7.
    # Replace those images *inside the same fixed scene*, not by layering photos
    # above the old thick books. The old v7 art is no longer visible.
    b = s.index('<style id="approved-scene-v7">')
    e = s.index('</style>', b)
    block = s[b:e]
    p = re.compile(r'background-image\s*:\s*url\(["\']data:image/png;base64,[A-Za-z0-9+/=]+["\']\)\s*!important\s*;')
    hits = p.findall(block)
    if len(hits) != 2:
        raise SystemExit(f'ABORT: expected exactly two v7 background images, found {len(hits)}')

    replacements = iter(
        'background-image:url("assets/vpc-scene/' + x + '")!important;'
        for x in ASSET_FILES
    )
    changed = p.sub(lambda _: next(replacements), block)
    s = s[:b] + changed + s[e:]

    # No floating note: remove the visible note element once and for all.
    note = re.compile(r'\s*<div class="art-hotspot art-note-hotspot" aria-hidden="true">\s*<span class="pin" aria-hidden="true"></span>\s*<span class="note-line">Articles,</span>\s*<span class="note-line">press release,</span>\s*<span class="note-line">blogs</span>\s*</div>', flags=re.S)
    s,note_count=note.subn('',s)
    if note_count != 1:
        raise SystemExit(f'ABORT: expected one floating note DOM element, got {note_count}')

    # Coordinates refer directly to the approved composition. Since the rendered
    # image is the actual scene background, these hit areas cannot float away.
    # Desktop art: 1600x900. Mobile art: 900x1600.
    css = '''\n<style id="vpc-approved-no-note-scene-20261117">
/* Approved image replacements only. Never draw cover images inside hit targets. */
.office-frame.approved-scene{
  background-size:100% 100%!important;
  background-position:center center!important;
  background-repeat:no-repeat!important;
}
.approved-scene .art-book{
  background:transparent!important;
  border:0!important;box-shadow:none!important;
  cursor:pointer!important;touch-action:manipulation!important;
}
.approved-scene .art-book::before,.approved-scene .art-book::after{content:none!important;display:none!important;}
/* The article pin has been retired from both desktop and mobile. */
.approved-scene .art-note-hotspot,.desktop-note,.mobile-note,.note-pin{display:none!important;}
/* Desktop: accurate clickable regions for the four front-facing covers. */
.approved-scene .art-book-1{left:4.65%!important;top:44.2%!important;width:16.4%!important;height:49.2%!important;}
.approved-scene .art-book-2{left:21.1%!important;top:45.8%!important;width:15.4%!important;height:46.8%!important;}
.approved-scene .art-book-3{left:36.45%!important;top:47.4%!important;width:13.8%!important;height:43.7%!important;}
.approved-scene .art-book-4{left:50.2%!important;top:48.7%!important;width:13.7%!important;height:41.6%!important;}
@media(max-width:700px){
  .office-frame.approved-scene{background-size:100% 100%!important;}
  .approved-scene .art-book-1{left:2.6%!important;top:50.6%!important;width:24%!important;height:24.2%!important;}
  .approved-scene .art-book-2{left:26.0%!important;top:51.2%!important;width:22.8%!important;height:23.5%!important;}
  .approved-scene .art-book-3{left:48.6%!important;top:51.8%!important;width:21.5%!important;height:22.8%!important;}
  .approved-scene .art-book-4{left:70.0%!important;top:52.3%!important;width:21.0%!important;height:22.3%!important;}
}
</style>\n'''
    if s.count('</head>') != 1:
        raise SystemExit('ABORT: expected one </head>')
    s = s.replace('</head>', css+'</head>', 1)

    # Invariants of the original site, independent of bytes inside the book data.
    assert MARKER in s
    assert 'assets/vpc-scene/vpc-scene-desktop-20261117.jpg' in s
    assert 'assets/vpc-scene/vpc-scene-mobile-20261117.jpg' in s
    assert 'class="art-hotspot art-note-hotspot"' not in s
    assert s.count('class="art-hotspot art-book art-book-') == 4
    assert len(s) > 2_000_000
    assert 'VPC Publishing | Books by Victoria P. Carlos' in s
    assert 'https://www.lazada.com.ph/shop/vpc-publishing/' in s
    assert 'nationalbookstore.com/pages/stores' in s
    assert 'fullybookedonline.com' in s
    assert 'function openReader(i)' in s
    assert 'function closeReader()' in s
    # Check that no unrelated JavaScript was edited.
    assert INDEX.read_text(encoding='utf-8').split('<script>',1)[1] == s.split('<script>',1)[1]

    ASSETS.mkdir(parents=True,exist_ok=True)
    for name in ASSET_FILES:
        shutil.copyfile(SRC / name, ASSETS / name)
    INDEX.write_text(s, encoding='utf-8')
    print('Installed approved VPC scene; no floating note.')
    print('Original scene artwork removed from v7 styles; original readers/links retained.')
    print('Assets:',[(p.name,p.stat().st_size) for p in ASSETS.glob('vpc-scene-*.jpg')])
    print('index.html:',INDEX.stat().st_size,'bytes')

if __name__ == '__main__': main()
