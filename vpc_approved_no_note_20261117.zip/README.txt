VPC Publishing — approved no-note scene installer (November 17, 2026)

Contains two scene backgrounds: desktop and mobile. Neither has the floating note.
The four slim books are part of the background artwork, NOT floating HTML overlays.

To install using the already prepared GitHub workflow:
1. Open https://github.com/proudlyph/vpc-publishing
2. Choose Add file > Upload files.
3. Upload THIS ZIP to the repository ROOT (not a subfolder), and commit it to main.
4. The workflow named "Install approved VPC note-free bookshelf scene" installs the assets and updates index.html safely.
5. Check the GitHub Actions run and deployed site on desktop and phone.

Do NOT upload the extracted PNG/JPEG files one by one.
The old VPC wall, reader functionality, shopping links, metadata and existing pages are preserved.
The pinned note is removed from the visible page by replacing both background images and deleting its HTML block.
This package has been verified against a synthetic equivalent of the VPC document structure; actual site behavior requires deployment verification.
