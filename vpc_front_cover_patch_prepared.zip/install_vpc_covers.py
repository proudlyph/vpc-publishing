from pathlib import Path
import re, zipfile, hashlib

ROOT = Path('.')
PACKAGE = ROOT / 'vpc_front_cover_patch_prepared.zip'
PAGE = ROOT / 'index.html'
assert PAGE.exists() and PACKAGE.exists(), 'index.html and front-cover ZIP required'
s = PAGE.read_text('utf-8')
assert len(s)>11_000_000 and 'office-frame approved-scene' in s, 'Unexpected site version; aborting'
assert 'vpc-exact-front-covers-20261117' not in s, 'Already applied; aborting safely'

mapping = {
 1: ('assets/book-covers/vpc-filipino-1-front.jpg', '6dee9fdc586b722bdd5a0203cdc59bbc71d02e736dd1c24c2e13bbad0a6034c6'),
 2: ('assets/book-covers/vpc-filipino-2-front.jpg', 'bb47da5f524c99b807bbf3dae1bf44ceb68346d3be91953fe522b892d108482f'),
 3: ('assets/book-covers/vpc-filipino-3-front.jpg', 'cf5549c25341ae438f03d232737993f988ed9a67d9b9f051ee311e52f1315b1d'),
 4: ('assets/book-covers/vpc-filipino-4-front.jpg', '809e90fab521a907a775515f445b826a222d1cf0c6da0bf2e495d2ddf5a58a92'),
}
with zipfile.ZipFile(PACKAGE) as z:
 for n, (source, expected) in mapping.items():
  raw=z.read(source)
  assert hashlib.sha256(raw).hexdigest()==expected, f'Cover {n} digest mismatch'
  target=ROOT/source
  target.parent.mkdir(parents=True, exist_ok=True)
  target.write_bytes(raw)

# Target only the four already-established transparent interactive buttons.
for n,(source,_) in mapping.items():
    needle = rf'(<button\b[^>]*\bclass="[^"]*\bart-book-{n}\b[^"]*"[^>]*>)(\s*)(</button>)'
    image = f'<img class="vpc-authentic-cover" src="{source}" alt="Original front cover, Volume {n}" draggable="false" decoding="async">'
    s,count = re.subn(needle, lambda m:m.group(1)+image+m.group(3), s, count=1)
    assert count == 1, f'Cannot reliably find original Volume {n} button. Abort.'

style = '''
<style id="vpc-exact-front-covers-20261117">
/* Only the four existing book tap surfaces are changed; wall, scene and navigation untouched. */
.approved-scene .art-book{overflow:visible!important;isolation:isolate!important;}
.approved-scene .art-book>.vpc-authentic-cover{
  position:absolute!important;left:50%!important;bottom:0!important;
  max-width:100%!important;max-height:100%!important;
  width:auto!important;height:100%!important;object-fit:contain!important;
  transform:translateX(-50%)!important;border:0!important;border-radius:1px!important;
  box-shadow:0 5px 9px rgba(20,9,4,.25)!important;
  user-select:none!important;-webkit-user-drag:none!important;pointer-events:none!important;
}
@media(max-width:700px){
  .approved-scene .art-book>.vpc-authentic-cover{height:96%!important;max-width:98%!important;}
}
</style>
'''
assert s.count('</head>')==1
s=s.replace('</head>', style+'</head>',1)
PAGE.write_text(s,'utf-8')
print('Validated all four original JPEG hashes and replaced shelf button faces. Existing room image and reader preserved.')
