# VPC Publishing — Front Cover Correction (PREPARED, NOT DEPLOYED)

## Approved scope
Replace only four approximated visual representations of books on the office bookshelf with the authentic original front-cover images. This is specifically the owner's instruction: show *front covers only*, without the invented spine designs or exaggerated thickness.

## Assets (exact original user files, copied losslessly)
- Volume 1 (red): `assets/book-covers/vpc-filipino-1-front.jpg`
- Volume 2 (blue): `assets/book-covers/vpc-filipino-2-front.jpg`
- Volume 3 (yellow): `assets/book-covers/vpc-filipino-3-front.jpg`
- Volume 4 (white): `assets/book-covers/vpc-filipino-4-front.jpg`

SHA-256 file hashes and natural dimensions are in `cover-manifest.json`. No regenerated titles, no retouching, no approximate spines.

## Invariant site elements — do not change
- VPC PUBLISHING wall sign or wall view / camera angle / room geometry.
- Office / bookshelf wood material / lighting / background atmosphere.
- Pinned note (articles, blogs, press) and its links.
- Book selection, reader, book descriptions, all existing online and physical store links.
- Navigation arrows and existing mobile adjustments.
- Social preview, SEO metadata, custom domain and deploy workflows.

## Source-level implementation, for the current repository (`proudlyph/vpc-publishing`, `main`)
1. Preserve a copy of the current `index.html` and its commit SHA before any edit.
2. Add the four images under `assets/book-covers/` unchanged.
3. Identify ONLY the drawing routine and/or CSS geometry responsible for **four visible books on the main office bookshelf**. Do NOT replace book pages in the interactive reader or books in the background decor.
4. In that routine, substitute a front-cover-only textured rectangle, preserving each book's existing clickable hitbox and associated volume. Draw/load each corresponding JPEG directly (`object-fit: contain` for DOM; `drawImage` without source cropping for canvas). Ensure Volume 1=red, 2=blue, 3=yellow, 4=white.
5. Remove synthetic spine widths, extruded side polygons, chunky page-block effects and invented edge lettering for these four foreground books. Retain at most a subtle contact shadow (`rgba(0,0,0,.18)`, small blur) so books naturally rest on the existing shelf.
6. Keep all four entire covers unobstructed, including borders, series titles and Victoria P. Carlos. Maintain natural aspect ratios and do not stretch the images.
7. On mobile screens, reduce display size or adjust front-cover spacing ONLY, not the view/camera; no overlap and easy tap targets.
8. Validate before publishing: scene visual desktop + portrait mobile, wall and pinned note untouched, four distinct covers correct, all four books clickable, book-reader transitions and purchase links remain functional, no console/asset 404 errors, social preview unchanged.
9. Publish only after successful diff review. Do not assume this pack itself patches the website.

## Code integration example (NOT a drop-in patch)
```js
const vpcCoverPaths = {
  1: 'assets/book-covers/vpc-filipino-1-front.jpg',
  2: 'assets/book-covers/vpc-filipino-2-front.jpg',
  3: 'assets/book-covers/vpc-filipino-3-front.jpg',
  4: 'assets/book-covers/vpc-filipino-4-front.jpg'
};
// Canvas drawing routine after images have loaded:
// g.drawImage(vpcCoverImages[volume], x, y, width, height);
// height = width * image.naturalHeight / image.naturalWidth;
// Do not paint any extruded spine/side face or synthesized lettering.
// Reuse the existing click handler and bounding box for that volume.
```

## Why no automated code patch is included
The repository's live `index.html` is about 11.8 MB and the available GitHub connector returned an empty content payload when asked to read it. Without examining that exact implementation, a search/replace script that promises to preserve the view and interactions would be unsafe. This pack is an asset-complete, implementation-specific staging package; it does not claim code changes were made or tested.
